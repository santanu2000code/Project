export class ItemClass {
  _id: string;
  itemname: string;
  itemdesc: string;
  price: number;
}
