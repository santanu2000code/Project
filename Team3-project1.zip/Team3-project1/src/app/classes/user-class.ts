export class UserClass {
  _id: string='';
  username: string='';
  emailid: string='';
  password: string='';
  Phoneno1: string='';
  Phoneno2: string='';
  confirmPassword: string='';
  address: string='';
}
