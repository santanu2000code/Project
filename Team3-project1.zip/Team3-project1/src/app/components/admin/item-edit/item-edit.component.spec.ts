import { ComponentFixture, TestBed } from '@angular/core/testing';

import { C13ItemEditComponent } from './c13-item-edit.component';

describe('C13ItemEditComponent', () => {
  let component: C13ItemEditComponent;
  let fixture: ComponentFixture<C13ItemEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ C13ItemEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(C13ItemEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
