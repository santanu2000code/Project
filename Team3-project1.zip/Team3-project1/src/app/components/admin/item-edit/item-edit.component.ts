import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/services/item.service';
import { ActivatedRoute, Router } from '@angular/router';
import {first} from "rxjs/operators";

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class C13ItemEditComponent implements OnInit {

  _id:any
  itemname:any
  itemdesc:any
  price:any

  constructor(private route: ActivatedRoute, private itemService: ItemService, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['id'];
      console.log(this._id);
    })
    this.itemService.getItemById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        this.itemname = data1.itemname;
        this.itemdesc = data1.itemdesc;
        this.price    = data1.price;
      },
      error => {
        alert(error);
      });
  }

  editItem() {
    var body = "_id=" + this._id 
        + "&itemname=" + this.itemname 
        + "&itemdesc=" + this.itemdesc 
        + "&price=" + this.price;
    // console.log(body)
    this.itemService.updateItem(body,this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['item-list']);
        },
        error => {
          alert(error);
        });
  }
}
