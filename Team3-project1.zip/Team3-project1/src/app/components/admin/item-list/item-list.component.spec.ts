import { ComponentFixture, TestBed } from '@angular/core/testing';

import { C11ItemListComponent } from './c11-item-list.component';

describe('C11ItemListComponent', () => {
  let component: C11ItemListComponent;
  let fixture: ComponentFixture<C11ItemListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ C11ItemListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(C11ItemListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
