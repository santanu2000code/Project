import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-order',
  templateUrl: './confirm-order.component.html',
  styleUrls: ['./confirm-order.component.css']
})
export class ConfirmOrderComponent implements OnInit {

  orderArray: any[] = [];
  totalAmt: string='';
  isOrdered: boolean = false;
  isProcessing: boolean = false;
  addressNotFound: boolean = false;
  notAvailableItems: any[] = [];
  orders: any;
  isLoading: boolean = true;
  isLoaded: boolean = false;

  itemAvailabilityChecked: boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  getItemTotalAmount(price: number, quantity: number) {
      return Number(price) * Number(quantity);
    }
}
