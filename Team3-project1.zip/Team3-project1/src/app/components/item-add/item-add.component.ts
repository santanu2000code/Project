
import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from "@angular/router";
import { ItemService } from './../../services/item.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-item-add',
  templateUrl: './item-add.component.html',
  styleUrls: ['./item-add.component.css']
})
export class ItemAddComponent implements OnInit {
  itemname: any
  itemdesc: any
  price: any
  message = ''
  uploadedFiles:Array<File> | undefined

  constructor(private router:Router, private itemService:ItemService, private elementRef:ElementRef,
    private http:HttpClient) { }

  ngOnInit(): void {
  }

  fileChange(element: { target: { files: File[]; }; }) {
    this.uploadedFiles = element.target.files;
  }

  addItem = function(this: ItemAddComponent) {
    let inputEl: HTMLInputElement = this.elementRef.nativeElement.querySelector('#file1');
    var formData = new FormData();
    formData.append("itemname", this.itemname);
    formData.append("itemdesc", this.itemdesc);
    formData.append("price",    this.price);
    // formData.append('file1', inputEl.files.item(0));

    // console.log('2. formData')
    // formData.forEach((value, key) => {
    //   console.log(key+" : "+value)
    // });

    // this.http.post('http://localhost:9000/v1/item', formData).subscribe(
    //   (response) => console.log(response),
    //   (error) => console.log(error)
    //   )
  
    this.itemService.createItem(formData).subscribe(
      (      result: any) => {
        this.router.navigate(['item-list']);
      },
      (      error: any) => {
        //this.message = error.error
        alert('Error while Adding an Item!')
      });
  }

  clearMessage() {
    this.message = ''
  }

}
