import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }
  itemArray=[
    {_id:1,itemname:"Idli",itemdesc:"1 Dosa, chuntny and sambar",imagefilename:"../../../assets/menu/idli.jpg",price:100,qnt:1},
    {_id:2,itemname:"Dosa",itemdesc:"1 Dosa, chuntny and sambar",imagefilename:"../../../assets/menu/dosa.jpg",price:150,qnt:1},
    {_id:3,itemname:"Chicken Biriyani",itemdesc:"Chicken Biriyani with raita",imagefilename:"../../../assets/menu/biriyani.jpg",price:400,qnt:1},
    {_id:4,itemname:"Upma",itemdesc:"Rava and Vegetable Upma",imagefilename:"../../../assets/menu/4-Upma.jpg",price:80,qnt:1},
    {_id:5,itemname:"Veg Full Meal",itemdesc:"Veg Full meal with rice,samabr,rasam,pickle,",imagefilename:"../../../assets/menu/5.FullmealVeg.jpg",price:250,qnt:1},
    {_id:6,itemname:"Chicken Kabab",itemdesc:"1 plate chicken kabab with lemmon and onions",imagefilename:"../../../assets/menu/6.ChickenKabab.jpg",price:300,qnt:1},
    {_id:7,itemname:"Lemon rice",itemdesc:"Lemon rice with chutny and pickle",imagefilename:"../../../assets/menu/7-Lemon rice.jpg",price:100,qnt:1},
    {_id:8,itemname:"Veg Palao",itemdesc:"1 Vegetable Palao with raita",imagefilename:"../../../assets/menu/8-veg-pulav.jpg",price:150,qnt:1},
    {_id:9,itemname:"Butter Nan",itemdesc:"2 butter Nan with Panner butter masala",imagefilename:"../../../assets/menu/9-butternan.jpg",price:300,qnt:1},
    {_id:10,itemname:"Jeera rice",itemdesc:"Jeera rice with Dal",imagefilename:"../../../assets/menu/10-jeeraRiceDal.JPG",price:200,qnt:1},
    {_id:11,itemname:"Mutton Biriyani",itemdesc:"1 Mutton Biriyani with raita, lemon and onions",imagefilename:"../../../assets/menu/11-muttonBiriyani.jpg",price:400,qnt:1},
    {_id:12,itemname:"Poori Saagu",itemdesc:"4 Poori Saagu with 2 saagu",imagefilename:"../../../assets/menu/poori-saagu.jpg",price:150,qnt:1},
  
  ];

inc(item:any){
  // console.log(item.qnt);
  item.qnt += 1;
}
dec(item:any)
{
  // console.log(item.qnt);
  if(item.qnt!=1){
  item.qnt = item.qnt - 1;
} 
}
itemsCart:any=[];
addCart(item:any){
console.log(item);
let cartDataNull = localStorage.getItem('localCart')
if(cartDataNull == null){
  let storeDataGet:any = [];
  storeDataGet.push(item);
  localStorage.setItem('localCart',JSON.stringify(storeDataGet));
}
else{
  var id=item.item_id;
  let index:number= -1;
  // this.itemsCart = JSON.parse(localStorage.getItem('localCart'));
  for(let i=0; i<this.itemsCart.length;i++){
  if(parseInt(id) === parseInt(this.itemsCart[i].item_id)){
  this.itemsCart[i].qnt = item.qnt;
  index = i;
  break;
  }
  }
  if(index == -1){
    this.itemsCart.push(item);
    localStorage.setItem('localCart',JSON.stringify(item));
  }
  else{
    localStorage.setItem('localCart',JSON.stringify(item));
  }
}

localStorage.setItem('localCart', JSON.stringify(item));
}

}
