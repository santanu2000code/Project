import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  username:string='';
  emailid:string='';
  password:string='';
  phoneno1:string='';
  phoneno2:string='';
  confirmpassword:string='';
  address:string='';

  message:any;
  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
  }

  addUser = () => {
    alert('registered')
    //var body = "id=" + this.id 
    var body = "username=" + this.username 
        + "&emailid=" + this.emailid 
        + "&password=" + this.password
        + "&address=" + this.address
        + "&phoneno1=" + this.phoneno1
        + "&phoneno2=" + this.phoneno2
       + "&comments=" + ' '
        + "&blacklist=" + false;
	
    this.userService.createUser(body)
      .subscribe( data => {
        this.router.navigate(['login']);
      },
      (error) => {
        this.message = error.error
      });    
  }

  clearMessage() {
    this.message = ''
  }
}







//   ngOnInit(): void {
//     this.initForm()
// }
// initForm(){
//   this.registerGroup = new FormGroup({
//     username: new FormControl('',[Validators.required]),
//     emailid: new FormControl('',[Validators.required,Validators.email]),
//     address: new FormControl('',[Validators.required]),
//     phoneno: new FormControl('',[Validators.required]),
//     password: new FormControl('',[Validators.required]),
//     cpassword: new FormControl('',[Validators.required])
//   })
// }

// registerProcess(){
  
//   if(this.registerGroup.valid){
//     this.foodservice.register(this.registerGroup.value).subscribe(result=>{
//       // if(result.success){
//       this.router.navigate(['login']);
//       console.log(result)
//       //  // alert("register success")
//       // }
//       // else{
//       //   alert("register failed")
//       // }
//     })
//   }
// }

// }